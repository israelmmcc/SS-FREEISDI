<?php
header("Location: public");
?>