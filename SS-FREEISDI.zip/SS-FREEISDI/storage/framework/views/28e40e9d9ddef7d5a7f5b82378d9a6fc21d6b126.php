<div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                <li @click="menu=0" class="nav-item">
                        <center><a class="nav-link active" href="#"><img src="http://icons.iconarchive.com/icons/webalys/kameleon.pics/512/Graph-Magnifier-icon.png"  width="40" height="40"></center></a>
                    </li>
               
                             <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.tol2javea.com/wp-content/uploads/2016/10/ICONO-PROYECTOS.png"  width="25" height="25"> Proyectos</a>
                        <ul class="nav-dropdown-items">
                       
                            <li @click="menu=2" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://secondlemon.com/wp-content/uploads/oferta-trabajo-desarrollador-backend.png"  width="25" height="25">Proyectos</a>
                            </li>
                        </ul>
                    </li>
                  

                  
                  
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.sccpre.cat/mypng/full/367-3670928_select-location-to-pay-bill-stukent-mimic-social.png"  width="25" height="25"> Pagos</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=3" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://compu-mecanic.com/wp-content/uploads/2018/06/web-hosting.png"  width="25" height="25"> Pagos a Servicios</a>
                            </li>
                     
                        </ul>
                    </li>
          
                </ul>
            </nav>
            <button class="sidebar-minimizer brand-minimizer" type="button"></button>
        </div>