<div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
               <li @click="menu=0" class="nav-item">
                        <center><a class="nav-link active" href="#"><img src="http://icons.iconarchive.com/icons/webalys/kameleon.pics/512/Graph-Magnifier-icon.png"  width="40" height="40"></center></a>
                    </li>
                  
                         <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.tol2javea.com/wp-content/uploads/2016/10/ICONO-PROYECTOS.png"  width="25" height="25"> Proyectos</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=1" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://img.haikudeck.com/mi/df7cc8e4f8deec22f70eaf2055d4cf70.png"  width="25" height="25"> Desarrolladores</a>
                            </li>
                            <li @click="menu=2" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://secondlemon.com/wp-content/uploads/oferta-trabajo-desarrollador-backend.png"  width="25" height="25">Proyectos</a>
                            </li>
                        </ul>
                    </li>
                  
                               <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.androidpolice.com/wp-content/uploads/2018/03/nexus2cee_new-tasks-icon.png"  width="25" height="25">  Tareas</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=13" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://www.androidpolice.com/wp-content/uploads/2018/03/nexus2cee_new-tasks-icon.png"  width="25" height="25"> Tareas</a>
                            </li>
                        
                        </ul>
                    </li>
          
               
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://cdn.pixabay.com/photo/2016/09/30/17/29/shopping-1705800_960_720.png"  width="25" height="25"> Ventas</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=5" class="nav-item">
                                <a class="nav-link" href="#"><img src="http://biobaby.cl/images/comprar-en-linea.png"  width="25" height="25"> Ventas</a>
                            </li>
                            <li @click="menu=6" class="nav-item">
                                <a class="nav-link" href="#"><img src="http://www.tambiencomunicacion.com/wp-content/uploads/2014/11/icono-02.png"  width="25" height="25">  Clientes</a>
                            </li>
                        </ul>
                    </li>
                  
 
                </ul>
            </nav>
            <button class="sidebar-minimizer brand-minimizer" type="button"></button>
        </div>