<?php $__env->startSection('login'); ?>
<head>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-2848057313646853",
    enable_page_level_ads: true
  });
</script>
</head>

<div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card-group mb-0">
          <div class="card p-4">
          <form class="form-horizontal was-validated" method="POST" action="<?php echo e(route('login')); ?>">
          <?php echo e(csrf_field()); ?>

              <div class="card-body">
                <center>
                <img width="331" height="341" src="https://images.vexels.com/media/users/3/142575/isolated/preview/cea2cfe03b4c1c3f070b39f3c3277fea-logo-3d-triangulo-cubico-by-vexels.png">
       </center>
              <p class="text-muted">Ingresa los datos para tener acceso al sistema</p>
              <div class="form-group mb-3<?php echo e($errors->has('usuario' ? 'is-invalid' : '')); ?>">
                <span class="input-group-addon"><img src="http://www.shoppingandcharity.it/wp-content/uploads/no_img-3.png"  width="20" height="20"></span>
                <input type="text" value="<?php echo e(old('usuario')); ?>" name="usuario" id="usuario" class="form-control" placeholder="Usuario">
                <?php echo $errors->first('usuario','<span class="invalid-feedback">:message</span>'); ?>

              </div>
              <div class="form-group mb-4<?php echo e($errors->has('password' ? 'is-invalid' : '')); ?>">
                <span class="input-group-addon"><img src="https://cdn1.iconfinder.com/data/icons/round-ui/173/50-512.png"  width="20" height="20"></span>
                <input type="password" name="password" id="password" class="form-control" placeholder="Contraseña">
                <?php echo $errors->first('password','<span class="invalid-feedback">:message</span>'); ?>

              </div>
                                         <center>
                  <button type="submit" class="btn btn-primary px-4">Ingresar</button>
                        </center>    
            </div>
                  
          </form>
          </div>
  
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.contenido', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>