<!DOCTYPE html>
<html lang="es">
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 

  <title>Freeisdi</title>

  <link href="css/plantilla.css" rel="stylesheet">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-2848057313646853",
    enable_page_level_ads: true
  });
</script>
</head>

<body class="app flex-row align-items-center">
  <div class="container">
    <?php echo $__env->yieldContent('login'); ?>
  </div>

  <!-- Bootstrap and necessary plugins -->
  <script src="js/plantilla.js"></script>

</body>
</html>


<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> 
    </head>
    <body>
            <div id="app" class="content">
                <example-component></example-component><!--Añadimos nuestro componente vuejs-->
            </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script> 
    </body>
</html>
