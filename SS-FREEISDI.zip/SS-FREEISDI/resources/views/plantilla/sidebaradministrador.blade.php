<div class="sidebar">
            <nav class="sidebar-nav">
                <ul class="nav">
                    <li @click="menu=0" class="nav-item">
                        <center><a class="nav-link active" href="#"><img src="http://icons.iconarchive.com/icons/webalys/kameleon.pics/512/Graph-Magnifier-icon.png"  width="40" height="40"></center></a>
                    </li>
               
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.tol2javea.com/wp-content/uploads/2016/10/ICONO-PROYECTOS.png"  width="25" height="25"> Proyectos</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=1" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://img.haikudeck.com/mi/df7cc8e4f8deec22f70eaf2055d4cf70.png"  width="25" height="25"> Areas</a>
                            </li>
                            <li @click="menu=2" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://cdn.pixabay.com/photo/2016/11/14/17/39/group-1824145_960_720.png"  width="25" height="25">Desarrolladores</a>
                            </li>
                                    <li @click="menu=5" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://secondlemon.com/wp-content/uploads/oferta-trabajo-desarrollador-backend.png"  width="25" height="25"> Proyectos</a>
                            </li>
                          
                          
                                 <li @click="menu=13" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://ca-capital.com/wp-content/uploads/2016/12/tramitessencillos.png"  width="25" height="25"> Incidencias</a>
                            </li>
                        </ul>
                    </li>
                  
                  
    
                  
                             
                  
                  
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://www.sccpre.cat/mypng/full/367-3670928_select-location-to-pay-bill-stukent-mimic-social.png"  width="25" height="25"> Pagos</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=3" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://www.sccpre.cat/mypng/full/367-3670928_select-location-to-pay-bill-stukent-mimic-social.png"  width="25" height="25"> Pagos</a>
                            </li>
                           <li @click="menu=4" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://image.flaticon.com/icons/png/512/235/235264.png"  width="25" height="25">  Proveedores</a>
                            </li>
                          
                      
                        </ul>
                    </li>
                  
                  
                  
 
                  
                  
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="http://www.tambiencomunicacion.com/wp-content/uploads/2014/11/icono-02.png"   width="25" height="25"> Clientes</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=6" class="nav-item">
                                <a class="nav-link" href="#"><img src="http://www.tambiencomunicacion.com/wp-content/uploads/2014/11/icono-02.png"  width="25" height="25">  Clientes</a>
                            </li>
                        </ul>
                    </li>
                  
                  
                  
                    <li class="nav-item nav-dropdown">
                        <a class="nav-link nav-dropdown-toggle" href="#"><img src="https://idp.asturias.es/nidp/recursos/d437f904-93f4-46cc-a784-46580c457359.png"  width="25" height="25"> Acceso</a>
                        <ul class="nav-dropdown-items">
                            <li @click="menu=7" class="nav-item">
                                <a class="nav-link" href="#"><img src="http://www.tambiencomunicacion.com/wp-content/uploads/2014/11/icono-02.png"  width="25" height="25"> Usuarios</a>
                            </li>
                            <li @click="menu=8" class="nav-item">
                                <a class="nav-link" href="#"><img src="https://cdn.iconscout.com/icon/premium/png-256-thumb/roles-107521.png"  width="25" height="25">  Roles</a>
                            </li>
                        </ul>
                    </li>
                  
                  
         
 
                  
                </ul>
            </nav>
            <button class="sidebar-minimizer brand-minimizer" type="button"></button>
        </div>