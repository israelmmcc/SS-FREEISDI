<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Equipo;
use App\DetalleEquipo;

class EquipoController extends Controller
{
    public function index(Request $request)
    {
        if (!$request->ajax()) return redirect('/');

        $buscar = $request->buscar;
        $criterio = $request->criterio;
        
        if ($buscar==''){
            $equipos = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
            ->join('users','equipos.idusuario','=','users.id')
            ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
            'equipos.num_comprobante','equipos.fecha_hora','equipos.impuesto','equipos.total',
            'equipos.estado','articulos.nombre','users.usuario')
            ->orderBy('articulos.id', 'desc')->paginate(10);
        }
        else{
            $equipos = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
            ->join('users','equipos.idusuario','=','users.id')
            ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
            'equipos.num_comprobante','equipos.fecha_hora','equipos.impuesto','equipos.total',
            'equipos.estado','articulos.nombre','users.usuario')
            ->where('equipos.'.$criterio, 'like', '%'. $buscar . '%')
            ->orderBy('equipos.id', 'desc')->paginate(10);
        }
        
        return [
            'pagination' => [
                'total'        => $equipos->total(),
                'current_page' => $equipos->currentPage(),
                'per_page'     => $equipos->perPage(),
                'last_page'    => $equipos->lastPage(),
                'from'         => $equipos->firstItem(),
                'to'           => $equipos->lastItem(),
            ],
            'equipos' => $equipos
        ];
    }
    public function obtenerCabecera(Request $request){
        if (!$request->ajax()) return redirect('/');

        $id = $request->id;
        $equipo = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
        ->join('users','equipos.idusuario','=','users.id')
        ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
        'equipos.num_comprobante','equipos.fecha_hora','equipos.impuesto','equipos.total',
        'equipos.estado','articulos.nombre','users.usuario')
        ->where('equipos.id','=',$id)
        ->orderBy('equipos.id', 'desc')->take(1)->get();
        
        return ['equipo' => $equipo];
    }
  
  ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
  
  public function obtenerDetalles(Request $request){
        if (!$request->ajax()) return redirect('/');

        $id = $request->id;
        $detalles = DetalleEquipo::join('categorias','detalle_equipos.idcategoria','=','categorias.id')
        ->select('detalle_equipos.cantidad','detalle_equipos.precio','detalle_equipos.descuento',
        'categorias.nombre as categoria')
        ->where('detalle_equipos.idequipo','=',$id)
        ->orderBy('detalle_equipos.id', 'desc')->get();
        
        return ['detalles' => $detalles];
    }
      
    public function listarPdf(){
        $equipos = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
        ->join('users','equipos.idusuario','=','users.id')
            ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
            'equipos.num_comprobante','equipos.fecha_hora','equipos.impuesto','equipos.total',
            'equipos.estado','articulos.nombre','users.usuario')
            ->orderBy('equipos.id', 'desc')->get();
        $cont=Equipo::count();

        $pdf = \PDF::loadView('pdf.equipospdf',['equipos'=>$equipos,'cont'=>$cont])->setPaper('a4', 'landscape');
        return $pdf->download('equipos.pdf');
    }

    public function pdf(Request $request,$id){
        $equipo = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
        ->join('users','equipos.idusuario','=','users.id')
        ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
        'equipos.num_comprobante','equipos.created_at','equipos.impuesto','equipos.total',
        'equipos.estado','articulos.nombre','users.usuario')
        ->where('equipos.id','=',$id)
        ->orderBy('equipos.id', 'desc')->take(1)->get();

        $detalles = DetalleEquipo::join('categorias','detalle_equipos.idcategoria','=','categorias.id')
        ->select('detalle_equipos.cantidad','detalle_equipos.precio','detalle_equipos.descuento',
        'categorias.nombre as categoria')
        ->where('detalle_equipos.idequipo','=',$id)
        ->orderBy('detalle_equipos.id', 'desc')->get();

        $numequipo=Equipo::select('num_comprobante')->where('id',$id)->get();

        $pdf = \PDF::loadView('pdf.equipo',['equipo'=>$equipo,'detalles'=>$detalles]);
        return $pdf->download('equipo-'.$numequipo[0]->num_comprobante.'.pdf');
    }

    public function pdfTicket(Request $request,$id){
        $equipo = Equipo::join('articulos','equipos.idarticulo','=','articulos.id')
        ->join('users','equipos.idusuario','=','users.id')
        ->select('equipos.id','equipos.tipo_comprobante','equipos.serie_comprobante',
        'equipos.num_comprobante','equipos.created_at','equipos.impuesto','equipos.total',
         'equipos.estado','articulos.nombre','users.usuario')
        ->where('equipos.id','=',$id)
        ->orderBy('equipos.id', 'desc')->take(1)->get();

        $detalles = DetalleEquipo::join('categorias','detalle_equipos.idcategoria','=','categorias.id')
        ->select('detalle_equipos.cantidad','detalle_equipos.precio','detalle_equipos.descuento',
        'categorias.nombre as categoria')
        ->where('detalle_equipos.idequipo','=',$id)
        ->orderBy('detalle_equipos.id', 'desc')->get();

        $numequipo=Equipo::select('num_comprobante')->where('id',$id)->get();

        $pdf = \PDF::loadView('pdf.ventaticket',['equipo'=>$equipo,'detalles'=>$detalles]);
        return $pdf->download('equipoTicket-'.$numequipo[0]->num_comprobante.'.pdf');
    }

    public function store(Request $request)
    {
        if (!$request->ajax()) return redirect('/');

        try{
            DB::beginTransaction();

            $mytime= Carbon::now('America/Lima');

            $equipo = new Equipo();
            $equipo->idarticulo = $request->idarticulo;
            $equipo->idusuario = \Auth::user()->id;
            $equipo->tipo_comprobante = $request->tipo_comprobante;
            $equipo->serie_comprobante = $request->serie_comprobante;
            $equipo->num_comprobante = $request->num_comprobante;
            $equipo->fecha_hora = $mytime->toDateString();
            $equipo->impuesto = $request->impuesto;
            $equipo->total = $request->total;
            $equipo->estado = 'Registrado';
            $equipo->save();

            $detalles = $request->data;//Array de detalles
            //Recorro todos los elementos

            foreach($detalles as $ep=>$det)
            {
                $detalle = new DetalleEquipo();
                $detalle->idequipo = $equipo->id;
                $detalle->idcategoria = $det['idcategoria'];
                $detalle->cantidad = $det['cantidad'];
                $detalle->precio = $det['precio'];
                $detalle->descuento = $det['descuento'];         
                $detalle->save();
            }       
            DB::commit();
            return [
                'id' => $equipo->id
            ];
        } catch (Exception $e){
            DB::rollBack();
        }
    }

    public function desactivar(Request $request)
    {
        if (!$request->ajax()) return redirect('/');
        $equipo = Equipo::findOrFail($request->id);
        $equipo->estado = 'Anulado';
        $equipo->save();
    }
}