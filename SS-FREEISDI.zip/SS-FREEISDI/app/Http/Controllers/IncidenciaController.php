<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use Illuminate\Support\Facades\DB;
use App\Incidencia;

class IncidenciaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if (!$request->ajax()) return redirect('/');

        $buscar = $request->buscar;
        $criterio = $request->criterio;
        
        if ($buscar==''){
            $incidencias = Incidencia::orderBy('id', 'desc')->paginate(10);
        }
        else{
            $incidencias = Incidencia::where($criterio, 'like', '%'. $buscar . '%')->orderBy('id', 'desc')->paginate(10);
        }
        

        return [
            'pagination' => [
                'total'        => $incidencias->total(),
                'current_page' => $incidencias->currentPage(),
                'per_page'     => $incidencias->perPage(),
                'last_page'    => $incidencias->lastPage(),
                'from'         => $incidencias->firstItem(),
                'to'           => $incidencias->lastItem(),
            ],
            'incidencias' => $incidencias
        ];
    }

    public function selectIncidencia(Request $request){
        if (!$request->ajax()) return redirect('/');
        $incidencias = Incidencia::where('condicion','=','1')
        ->select('id','nombre')->orderBy('nombre', 'asc')->get();
        return ['incidencias' => $incidencias];
    }

    public function listarPdf(){
        $incidencias = Incidencia::select('nombre','descripcion','condicion')->orderBy('nombre', 'asc')->get();
        $cont=Incidencia::count();

        $pdf = \PDF::loadView('pdf.incidenciaspdf',['incidencias'=>$incidencias,'cont'=>$cont])->setPaper('a4', 'portrait');
        return $pdf->download('incidencias.pdf');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        if (!$request->ajax()) return redirect('/');
        $incidencia = new Incidencia();
        $incidencia->nombre = $request->nombre;
        $incidencia->descripcion = $request->descripcion;
        $incidencia->condicion = '1';
        $incidencia->save();
    }
  

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        if (!$request->ajax()) return redirect('/');
        $incidencia = Incidencia::findOrFail($request->id);
        $incidencia->nombre = $request->nombre;
        $incidencia->descripcion = $request->descripcion;
        $incidencia->condicion = '1';
        $incidencia->save();
    }

    public function desactivar(Request $request)
    {
        if (!$request->ajax()) return redirect('/');
        $incidencia = Incidencia::findOrFail($request->id);
        $incidencia->condicion = '0';
        $incidencia->save();
    }

    public function activar(Request $request)
    {
        if (!$request->ajax()) return redirect('/');
        $incidencia = Incidencia::findOrFail($request->id);
        $incidencia->condicion = '1';
        $incidencia->save();
    }

    
}