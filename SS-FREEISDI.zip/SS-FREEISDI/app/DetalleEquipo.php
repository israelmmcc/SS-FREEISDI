<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleEquipo extends Model
{
    protected $table = 'detalle_equipos';
    protected $fillable = [
        'idequipo', 
        'idcategoria',
        'cantidad',
        'precio',
        'descuento'
    ];
    public $timestamps = false;
}
